@extends('layouts.admin')

@section('content')
    <h2>Xin chào Quản trị viên</h2>
    <p>Đây là trang tổng quan quản trị.</p>
@endsection
